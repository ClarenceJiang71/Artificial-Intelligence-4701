
import numpy as np
import pandas as pd
import sys

def main():
    """
    YOUR CODE GOES HERE
    Implement Linear Regression using Gradient Descent, with varying alpha values and numbers of iterations.
    Write to an output csv file the outcome betas for each (alpha, iteration #) setting.
    Please run the file as follows: python3 lr.py data2.csv, results2.csv
    """
    input_name = sys.argv[1]
    output_name = sys.argv[2]

    df = pd.read_csv(input_name, header=None)
    mean0 = df[0].mean()
    std0 = df[0].std()
    mean1 = df[1].mean()
    std1 = df[1].std()
    df[0] = df[0].apply(lambda x : (x-mean0)/std0)
    df[1] = df[1].apply(lambda x : (x-mean1)/std1)


    # df[0] = [i[0] for i in df_scaled]
    # df[1] = [i[1] for i in df_scaled]
    df["b"] = 1

    result_df = pd.DataFrame(columns=["alpha", "num_iters", "bias", "b_age", "b_weight"])


    alpha_list = [0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1, 5, 10]
    for alpha in alpha_list:
        weight0 = 0
        weight1 = 0
        weight2 = 0
        for i in range(100):
            sum0 = 0
            sum1 = 0
            sum2 = 0

            for index, row in df.iterrows():
                sum0 = sum0 + weight0 + weight1 * row[0] + weight2 * row[1] - row[2]
                sum1 = sum1 + (weight0 + weight1 * row[0] + weight2 * row[1] - row[2])*row[0]
                sum2 = sum2 + (weight0 + weight1 * row[0] + weight2 * row[1] - row[2])*row[1]

            weight0 = weight0 - alpha * sum0/df.shape[0]
            weight1 = weight1 - alpha * sum1/df.shape[0]
            weight2 = weight2 - alpha * sum2/df.shape[0]
        # if alpha == 1:
        #     print("go here")
            # print(f"After Alpha {alpha}'s {i + 1} epoch, the result weights are weight1 {weight1}, weight2 {weight2}, bias {weight0}")
        result_df = result_df.append({"alpha": alpha, "num_iters": 100, "bias": round(weight0,3), "b_age": round(weight1,3), "b_weight": round(weight2,3)} \
                         ,ignore_index=True)
        # result_df = result_df.append(
        #     {"alpha": alpha, "num_iters": 100, "bias": weight0, "b_age": weight1,
        #      "b_weight": weight2} \
        #     , ignore_index=True)

    weight0 = 0
    weight1 = 0
    weight2 = 0
    for i in range(20):
        sum0 = 0
        sum1 = 0
        sum2 = 0

        for index, row in df.iterrows():
            sum0 = sum0 + weight0 + weight1 * row[0] + weight2 * row[1] - row[2]
            sum1 = sum1 + (weight0 + weight1 * row[0] + weight2 * row[1] - row[2]) * row[0]
            sum2 = sum2 + (weight0 + weight1 * row[0] + weight2 * row[1] - row[2]) * row[1]

        weight0 = weight0 - 0.9 * sum0 / df.shape[0]
        weight1 = weight1 - 0.9 * sum1 / df.shape[0]
        weight2 = weight2 - 0.9 * sum2 / df.shape[0]
        # print(f"After Alpha 0.9's {i + 1} epoch, the result weights are weight1 {weight1}, weight2 {weight2}, bias {weight0}")

    result_df = result_df.append(
        {"alpha": 0.9, "num_iters": 20, "bias": round(weight0, 3), "b_age": round(weight1, 3),
         "b_weight": round(weight2, 3)}, ignore_index=True)
    # print(result_df)
    result_df.to_csv(output_name, index=False, header=False)







if __name__ == "__main__":
    main()