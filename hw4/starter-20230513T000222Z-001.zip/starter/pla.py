import pandas as pd
import numpy as np
import sys

def main():
    '''YOUR CODE GOES HERE'''
    input_name = sys.argv[1]
    output_name = sys.argv[2]
    df = pd.read_csv(input_name, header=None)
    df["b"] = 1
    result_df = pd.DataFrame(columns=["weight1", "weight2", "b"])
    weight0 = 0
    weight1 = 0
    weight2 = 0
    prev_weight0 = 1
    prev_weight1 = 1
    prev_weight2 = 1
    while weight1 != prev_weight1 or weight2 != prev_weight2 or prev_weight0 != weight0:
        result_df = result_df.append({"weight1": weight1, "weight2": weight2, "b": weight0}, ignore_index=True)
        prev_weight0 = weight0
        prev_weight1 = weight1
        prev_weight2 = weight2
        for index, row in df.iterrows():
            value = row[0] * weight1 + row[1]*weight2 + row["b"] * weight0
            sign = 0
            if value > 0:
                sign = 1
            elif value < 0:
                sign = -1
            if sign * row[2] <= 0:
                weight0 = weight0 + row[2] * row["b"]
                weight1 = weight1 + row[2] * row[0]
                weight2 = weight2 + row[2] * row[1]
            # result_df = result_df.append({"weight1": weight1, "weight2": weight2, "b": weight0}, ignore_index=True)

    result_df = result_df.append({"weight1": weight1, "weight2": weight2, "b": weight0}, ignore_index=True)

    result_df.to_csv(output_name, index=False, header=False)

if __name__ == "__main__":
    """DO NOT MODIFY"""
    main()